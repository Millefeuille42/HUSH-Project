ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1085589.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 42169222, 42169749 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/42169591/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/42169592/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/42169590/1/ammo.js', 'preload' : true},
];
